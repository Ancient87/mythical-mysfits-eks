export declare function getEnv(name: string): string;
export declare function log(title: any, ...args: any[]): void;
